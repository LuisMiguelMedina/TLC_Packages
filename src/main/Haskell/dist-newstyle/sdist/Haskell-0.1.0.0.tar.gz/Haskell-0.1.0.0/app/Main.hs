import Control.Exception (IOException, try,)
import System.IO (IOMode(WriteMode, ReadMode), hClose, hGetContents, hPutStr, openFile, Handle)
import Data.Bits (xor)
import Data.Char (chr, ord)
import System.IO.Error ( isDoesNotExistError )

main :: IO ()
main = do
  let inputFilePath = "C:/Users/luism/OneDrive/Escritorio/TLC_Bank/src/main/Haskell/app/datos/token.txt"
      key = "clave"
  
  -- Abrir el archivo de entrada para leer
  handleIn <- openFile inputFilePath ReadMode
  
  -- Leer el contenido del archivo
  contents <- hGetContents handleIn
  
  -- Descifrar los datos
  let decrypted = decrypt contents key
  
  -- Mostrar el resultado en la pantalla
  putStrLn decrypted

  -- Cifrar los datos descifrados
  let encrypted = encrypt decrypted key

  -- Escribir el resultado cifrado en un archivo de salida
  let outputFilePath = "C:/Users/luism/OneDrive/Escritorio/TLC_Bank/src/main/Haskell/app/datos/token.txt"
  handleOut <- try (openFile outputFilePath WriteMode) :: IO (Either IOException Handle)
  case handleOut of
    Left e
      | isDoesNotExistError e -> putStrLn "El archivo de salida no existe"
      | otherwise -> putStrLn $ "Error al abrir el archivo de salida: " ++ show e
    Right handle -> do
      hPutStr handle encrypted
      hClose handle
      putStrLn "Resultado cifrado guardado en el archivo de salida"

  -- Cerrar el archivo de entrada
  hClose handleIn

  -- Función para cifrar un mensaje utilizando una clave
encrypt :: String -> String -> String
encrypt msg key = zipWith (\x y -> chr (xor (ord x) (ord y))) msg (cycle key)

-- Función para descifrar un mensaje utilizando una clave
decrypt :: String -> String -> String
decrypt encrypted key = zipWith (\x y -> chr (xor (ord x) (ord y))) encrypted (cycle key)